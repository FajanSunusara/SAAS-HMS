package com.hotel.reception.repository;

import com.hotel.reception.model.entity.Payment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
    
    Optional<Payment> findByPaymentCode(String paymentCode);
    
    List<Payment> findByInvoiceInvoiceId(Long invoiceId);
    
    List<Payment> findByBookingBookingId(Long bookingId);
    
    List<Payment> findByGuestGuestId(Long guestId);
    
    List<Payment> findByPaymentDate(LocalDate paymentDate);
    
    List<Payment> findByPaymentMethod(String paymentMethod);
    
    @Query("SELECT p FROM Payment p WHERE p.paymentDate BETWEEN :start AND :end")
    List<Payment> findPaymentsBetweenDates(
            @Param("start") LocalDate start,
            @Param("end") LocalDate end
    );
    
    @Query("SELECT SUM(p.amountPaid) FROM Payment p WHERE p.paymentDate = :date AND p.status = 'COMPLETED'")
    BigDecimal getTotalCollectionByDate(@Param("date") LocalDate date);
    
    @Query("SELECT p.paymentMethod, SUM(p.amountPaid) FROM Payment p " +
           "WHERE p.paymentDate BETWEEN :start AND :end AND p.status = 'COMPLETED' " +
           "GROUP BY p.paymentMethod")
    List<Object[]> getPaymentMethodBreakdown(
            @Param("start") LocalDate start,
            @Param("end") LocalDate end
    );
    
    @Query("SELECT SUM(p.amountPaid) FROM Payment p WHERE p.createdAt BETWEEN :start AND :end")
    BigDecimal getTotalRevenueInPeriod(@Param("start") LocalDateTime start, @Param("end") LocalDateTime end);
    
    Page<Payment> findByPaymentDateBetween(LocalDate start, LocalDate end, Pageable pageable);
}
