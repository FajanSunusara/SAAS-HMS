package com.hotel.reception.service;

import com.hotel.reception.exception.*;
import com.hotel.reception.model.dto.request.BookingRequest;
import com.hotel.reception.model.dto.request.GuestRequest;
import com.hotel.reception.model.dto.response.BookingResponse;
import com.hotel.reception.model.dto.response.GuestResponse;
import com.hotel.reception.model.dto.response.RoomResponse;
import com.hotel.reception.model.entity.*;
import com.hotel.reception.repository.*;
import com.hotel.reception.util.BookingCodeGenerator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class BookingService {
    
    private final BookingRepository bookingRepository;
    private final GuestService guestService;
    private final RoomService roomService;
    private final BookingRoomRepository bookingRoomRepository;
    private final GroupMemberRepository groupMemberRepository;
    private final RoomPreferenceRepository roomPreferenceRepository;
    private final RoomRepository roomRepository;
    
    public BookingResponse createBooking(BookingRequest request) {
        log.info("Creating new booking of type: {}", request.getBookingType());
        
        // Validate dates
        validateBookingDates(request.getCheckInDate(), request.getCheckOutDate());
        
        // Get or create guest
        Guest primaryGuest = getOrCreateGuest(request);
        
        // Validate room availability
        validateRoomAvailability(request.getRoomIds(), request.getCheckInDate(), request.getCheckOutDate());
        
        // Create booking
        Booking booking = new Booking();
        booking.setBookingCode(BookingCodeGenerator.generate());
        booking.setGuest(primaryGuest);
        booking.setBookingType(request.getBookingType());
        booking.setBookingSource(request.getBookingSource() != null ? request.getBookingSource() : "WALK_IN");
        booking.setCheckInDate(request.getCheckInDate());
        booking.setCheckOutDate(request.getCheckOutDate());
        booking.setCheckInTime(request.getCheckInTime());
        booking.setCheckOutTime(request.getCheckOutTime());
        
        // Calculate nights
        long nights = ChronoUnit.DAYS.between(request.getCheckInDate(), request.getCheckOutDate());
        booking.setNights((int) nights);
        
        booking.setAdults(request.getAdults() != null ? request.getAdults() : 1);
        booking.setChildren(request.getChildren() != null ? request.getChildren() : 0);
        booking.setInfants(request.getInfants() != null ? request.getInfants() : 0);
        booking.setPurposeOfVisit(request.getPurposeOfVisit());
        booking.setSpecialInstructions(request.getSpecialInstructions());
        booking.setStatus("CONFIRMED");
        booking.setPaymentStatus("PENDING");
        
        // Set pricing
        booking.setDiscountPercentage(request.getDiscountPercentage() != null ? request.getDiscountPercentage() : BigDecimal.ZERO);
        booking.setManualDiscount(request.getManualDiscount() != null ? request.getManualDiscount() : BigDecimal.ZERO);
        booking.setTaxPercentage(request.getTaxPercentage() != null ? request.getTaxPercentage() : new BigDecimal("10.00"));
        booking.setIncludeTax(request.getIncludeTax() != null ? request.getIncludeTax() : true);
        booking.setTermsAccepted(request.getTermsAccepted() != null ? request.getTermsAccepted() : false);
        
        // Save booking
        Booking savedBooking = bookingRepository.save(booking);
        
        // Assign rooms
        assignRoomsToBooking(savedBooking, request.getRoomIds());
        
        // Handle group booking
        if ("GROUP".equals(request.getBookingType()) && request.getGroupMembers() != null) {
            addGroupMembers(savedBooking, request.getGroupMembers());
        }
        
        // Add room preferences
        if (request.getPreferences() != null) {
            addRoomPreferences(savedBooking, request.getPreferences());
        }
        
        // Update room status to RESERVED
        updateRoomStatuses(request.getRoomIds(), "RESERVED");
        
        log.info("Booking created successfully: {}", savedBooking.getBookingCode());
        return mapToResponse(savedBooking);
    }
    
    public BookingResponse getBookingById(Long bookingId) {
        log.debug("Fetching booking by ID: {}", bookingId);
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + bookingId));
        return mapToResponse(booking);
    }
    
    public BookingResponse getBookingByCode(String bookingCode) {
        log.debug("Fetching booking by code: {}", bookingCode);
        Booking booking = bookingRepository.findByBookingCode(bookingCode)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with code: " + bookingCode));
        return mapToResponse(booking);
    }
    
    public List<BookingResponse> getAllBookings() {
        return bookingRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    public Page<BookingResponse> searchBookings(String keyword, Pageable pageable) {
        Page<Booking> bookingPage = bookingRepository.searchBookings(keyword, pageable);
        return bookingPage.map(this::mapToResponse);
    }
    
    public List<BookingResponse> getTodayCheckIns() {
        LocalDate today = LocalDate.now();
        return bookingRepository.findTodayCheckIns(today).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    public List<BookingResponse> getTodayCheckOuts() {
        LocalDate today = LocalDate.now();
        return bookingRepository.findTodayCheckOuts(today).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    public BookingResponse updateBookingStatus(Long bookingId, String newStatus) {
        log.info("Updating booking {} status to {}", bookingId, newStatus);
        
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + bookingId));
        
        booking.setStatus(newStatus);
        Booking updatedBooking = bookingRepository.save(booking);
        
        // Update room statuses based on booking status
        if ("CANCELLED".equals(newStatus)) {
            booking.setCancelledAt(LocalDateTime.now());
            updateRoomStatusesForBooking(booking, "AVAILABLE");
        }
        
        log.info("Booking status updated: {}", bookingId);
        return mapToResponse(updatedBooking);
    }
    
    public void cancelBooking(Long bookingId, String reason) {
        log.info("Cancelling booking: {}", bookingId);
        
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + bookingId));
        
        booking.setStatus("CANCELLED");
        booking.setCancelledAt(LocalDateTime.now());
        booking.setCancellationReason(reason);
        
        bookingRepository.save(booking);
        
        // Free up rooms
        updateRoomStatusesForBooking(booking, "AVAILABLE");
        
        log.info("Booking cancelled: {}", bookingId);
    }
    
    // Helper methods
    private void validateBookingDates(LocalDate checkIn, LocalDate checkOut) {
        if (checkIn.isAfter(checkOut)) {
            throw new RuntimeException("Check-in date must be before check-out date");
        }
        if (checkIn.isBefore(LocalDate.now())) {
            throw new RuntimeException("Check-in date cannot be in the past");
        }
    }
    
    private Guest getOrCreateGuest(BookingRequest request) {
        if (request.getGuestId() != null) {
            return guestService.getGuestEntityById(request.getGuestId());
        } else if (request.getGuestDetails() != null) {
            GuestResponse guestResponse = guestService.createGuest(request.getGuestDetails());
            return guestService.getGuestEntityById(guestResponse.getGuestId());
        } else {
            throw new RuntimeException("Guest information is required");
        }
    }
    
    private void validateRoomAvailability(List<Long> roomIds, LocalDate checkIn, LocalDate checkOut) {
        for (Long roomId : roomIds) {
            List<Room> availableRooms = roomRepository.findAvailableRooms(checkIn, checkOut, null);
            boolean isAvailable = availableRooms.stream()
                    .anyMatch(room -> room.getRoomId().equals(roomId));
            
            if (!isAvailable) {
                Room room = roomService.getRoomEntityById(roomId);
                throw new RuntimeException("Room " + room.getRoomNumber() + " is not available for selected dates");
            }
        }
    }
    
    private void assignRoomsToBooking(Booking booking, List<Long> roomIds) {
        for (Long roomId : roomIds) {
            Room room = roomService.getRoomEntityById(roomId);
            
            BookingRoom bookingRoom = new BookingRoom();
            bookingRoom.setBooking(booking);
            bookingRoom.setRoom(room);
            bookingRoom.setRoomRate(room.getBaseRate());
            
            bookingRoomRepository.save(bookingRoom);
        }
    }
    
    private void addGroupMembers(Booking booking, List<GuestRequest> groupMemberRequests) {
        for (int i = 0; i < groupMemberRequests.size(); i++) {
            GuestRequest memberRequest = groupMemberRequests.get(i);
            GuestResponse memberResponse = guestService.createGuest(memberRequest);
            Guest memberGuest = guestService.getGuestEntityById(memberResponse.getGuestId());
            
            GroupMember groupMember = new GroupMember();
            groupMember.setBooking(booking);
            groupMember.setGuest(memberGuest);
            groupMember.setIsLeader(i == 0); // First member is leader
            
            groupMemberRepository.save(groupMember);
        }
    }
    
    private void addRoomPreferences(Booking booking, com.hotel.reception.model.dto.request.RoomPreferenceRequest prefRequest) {
        RoomPreference preference = new RoomPreference();
        preference.setBooking(booking);
        preference.setBedPreference(prefRequest.getBedPreference());
        preference.setSmokingPreference(prefRequest.getSmokingPreference());
        preference.setFloorPreference(prefRequest.getFloorPreference());
        preference.setViewPreference(prefRequest.getViewPreference());
        preference.setExtraBed(prefRequest.getExtraBed());
        preference.setCrib(prefRequest.getCrib());
        preference.setWheelchairAccess(prefRequest.getWheelchairAccess());
        preference.setEarlyCheckIn(prefRequest.getEarlyCheckIn());
        preference.setLateCheckOut(prefRequest.getLateCheckOut());
        
        roomPreferenceRepository.save(preference);
    }
    
    private void updateRoomStatuses(List<Long> roomIds, String status) {
        for (Long roomId : roomIds) {
            roomService.updateRoomStatus(roomId, status);
        }
    }
    
    private void updateRoomStatusesForBooking(Booking booking, String status) {
        List<BookingRoom> bookingRooms = bookingRoomRepository.findByBookingBookingId(booking.getBookingId());
        for (BookingRoom bookingRoom : bookingRooms) {
            roomService.updateRoomStatus(bookingRoom.getRoom().getRoomId(), status);
        }
    }
    
    private BookingResponse mapToResponse(Booking booking) {

        // Guest
        GuestResponse guestResponse =
                guestService.getGuestById(booking.getGuest().getGuestId());

        // Rooms
        List<BookingRoom> bookingRooms =
                bookingRoomRepository.findByBookingBookingId(booking.getBookingId());

        List<RoomResponse> roomResponses = bookingRooms.stream()
                .map(br -> roomService.getRoomById(br.getRoom().getRoomId()))
                .collect(Collectors.toList());

        // Group members
        List<GroupMember> groupMembers =
                groupMemberRepository.findByBookingBookingId(booking.getBookingId());

        List<GuestResponse> groupMemberResponses = groupMembers.stream()
                .map(gm -> guestService.getGuestById(gm.getGuest().getGuestId()))
                .collect(Collectors.toList());

        // ---- SAFE FINANCIAL CALCULATIONS ----

        int nights = booking.getNights() != null ? booking.getNights() : 1;

        BigDecimal roomCharges = bookingRooms.stream()
                .map(br ->
                        safe(br.getRoomRate())
                                .multiply(BigDecimal.valueOf(nights))
                )
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal discountPercentage = safe(booking.getDiscountPercentage());
        BigDecimal manualDiscount = safe(booking.getManualDiscount());
        BigDecimal taxPercentage = safe(booking.getTaxPercentage());

        BigDecimal subtotal = roomCharges;

        BigDecimal percentageDiscount = subtotal
                .multiply(discountPercentage)
                .divide(BigDecimal.valueOf(100), 2, BigDecimal.ROUND_HALF_UP);

        BigDecimal discountAmount = percentageDiscount.add(manualDiscount);

        BigDecimal afterDiscount = subtotal.subtract(discountAmount);

        BigDecimal taxAmount = afterDiscount
                .multiply(taxPercentage)
                .divide(BigDecimal.valueOf(100), 2, BigDecimal.ROUND_HALF_UP);

        BigDecimal totalAmount = afterDiscount.add(taxAmount);

        // ---- RESPONSE ----

        return BookingResponse.builder()
                .bookingId(booking.getBookingId())
                .bookingCode(booking.getBookingCode())
                .guest(guestResponse)
                .groupMembers(groupMemberResponses)
                .bookingType(booking.getBookingType())
                .bookingSource(booking.getBookingSource())
                .checkInDate(booking.getCheckInDate())
                .checkOutDate(booking.getCheckOutDate())
                .checkInTime(booking.getCheckInTime())
                .checkOutTime(booking.getCheckOutTime())
                .actualCheckIn(booking.getActualCheckIn())
                .actualCheckOut(booking.getActualCheckOut())
                .nights(nights)
                .adults(booking.getAdults())
                .children(booking.getChildren())
                .infants(booking.getInfants())
                .rooms(roomResponses)
                .status(booking.getStatus())
                .paymentStatus(booking.getPaymentStatus())
                .roomCharges(roomCharges)
                .serviceCharges(BigDecimal.ZERO)
                .subtotal(subtotal)
                .discountAmount(discountAmount)
                .taxAmount(taxAmount)
                .totalAmount(totalAmount)
                .amountPaid(BigDecimal.ZERO)
                .balanceDue(totalAmount)
                .purposeOfVisit(booking.getPurposeOfVisit())
                .specialInstructions(booking.getSpecialInstructions())
                .createdAt(booking.getCreatedAt())
                .createdBy(booking.getCreatedBy())
                .build();
    }

    
    private BigDecimal safe(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value;
    }

}
