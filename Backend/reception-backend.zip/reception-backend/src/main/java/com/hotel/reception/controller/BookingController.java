package com.hotel.reception.controller;

import com.hotel.reception.model.dto.request.BookingRequest;
import com.hotel.reception.model.dto.response.ApiResponse;
import com.hotel.reception.model.dto.response.BookingResponse;
import com.hotel.reception.service.BookingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1/bookings")
@RequiredArgsConstructor
@Tag(name = "Booking Management", description = "APIs for managing bookings (Walk-in, Group, Company)")
@CrossOrigin(origins = "*")
public class BookingController {
    
    private final BookingService bookingService;
    
    @Operation(summary = "Create new booking", description = "Supports SINGLE, GROUP, and COMPANY bookings")
    @PostMapping
    public ResponseEntity<ApiResponse<BookingResponse>> createBooking(
            @Valid @RequestBody BookingRequest request) {
        BookingResponse response = bookingService.createBooking(request);
        return new ResponseEntity<>(
                ApiResponse.success("Booking created successfully", response),
                HttpStatus.CREATED
        );
    }
    
    @Operation(summary = "Get booking by ID")
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<BookingResponse>> getBookingById(@PathVariable Long id) {
        BookingResponse response = bookingService.getBookingById(id);
        return ResponseEntity.ok(ApiResponse.success(response));
    }
    
    @Operation(summary = "Get booking by booking code")
    @GetMapping("/code/{code}")
    public ResponseEntity<ApiResponse<BookingResponse>> getBookingByCode(@PathVariable String code) {
        BookingResponse response = bookingService.getBookingByCode(code);
        return ResponseEntity.ok(ApiResponse.success(response));
    }
    
    @Operation(summary = "Get all bookings")
    @GetMapping
    public ResponseEntity<ApiResponse<List<BookingResponse>>> getAllBookings() {
        List<BookingResponse> responses = bookingService.getAllBookings();
        return ResponseEntity.ok(ApiResponse.success(responses));
    }
    
    @Operation(summary = "Search bookings")
    @GetMapping("/search")
    public ResponseEntity<ApiResponse<Page<BookingResponse>>> searchBookings(
            @RequestParam String keyword,
            Pageable pageable) {
        Page<BookingResponse> responses = bookingService.searchBookings(keyword, pageable);
        return ResponseEntity.ok(ApiResponse.success(responses));
    }
    
    @Operation(summary = "Get today's check-ins")
    @GetMapping("/checkins/today")
    public ResponseEntity<ApiResponse<List<BookingResponse>>> getTodayCheckIns() {
        List<BookingResponse> responses = bookingService.getTodayCheckIns();
        return ResponseEntity.ok(ApiResponse.success(responses));
    }
    
    @Operation(summary = "Get today's check-outs")
    @GetMapping("/checkouts/today")
    public ResponseEntity<ApiResponse<List<BookingResponse>>> getTodayCheckOuts() {
        List<BookingResponse> responses = bookingService.getTodayCheckOuts();
        return ResponseEntity.ok(ApiResponse.success(responses));
    }
    
    @Operation(summary = "Update booking status")
    @PatchMapping("/{id}/status")
    public ResponseEntity<ApiResponse<BookingResponse>> updateBookingStatus(
            @PathVariable Long id,
            @RequestParam String status) {
        
        BookingResponse response = bookingService.updateBookingStatus(id, status);
        return ResponseEntity.ok(ApiResponse.success("Booking status updated", response));
    }
    
    @Operation(summary = "Cancel booking")
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> cancelBooking(
            @PathVariable Long id,
            @RequestParam(required = false) String reason) {
        
        bookingService.cancelBooking(id, reason);
        return ResponseEntity.ok(ApiResponse.success("Booking cancelled successfully", null));
    }
}
